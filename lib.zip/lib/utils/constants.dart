// class AppConfig {
//   static const String baseUrl = "http://localhost:8000/api";
// }